pyvmomi-community-samples testing
=================================

In the event that you can write tests for your samples, submit them here.